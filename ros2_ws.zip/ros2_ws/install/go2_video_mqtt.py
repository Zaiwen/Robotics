"""
GO2 HTTP → MQTT 视频代理（高清晰度低延迟版）
"""

import requests
import cv2
import numpy as np
import paho.mqtt.client as mqtt
import base64
import json
import time
import threading
from queue import Queue, Empty
import io
import struct


# 视频代理
class GO2VideoProxy:
    def __init__(self):
        # 5001 对应 /color/image_raw，通常比 5000 的 /image_raw 更稳定且帧率更高
        self.video_url = "http://127.0.0.1:5001/video_stream"
        self.mqtt_broker = '10.121.151.103'
        self.mqtt_port = 1883
        self.video_topic = 'go2/video/stream'
        
        # 关键：只保留最新帧的队列（大小=1，自动丢旧帧）
        self.frame_queue = Queue(maxsize=1)
        self.latest_frame_time = 0

        # 1200ms 视频帧最大保留时间
        self.max_frame_age_ms = 1200

        # fps是帧率上限，1s 20帧
        self.target_fps = 20
        # 默认直通 JPEG，减少重复 imdecode/imencode 带来的 CPU 开销
        self.use_passthrough = True
        
        self.client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"go2_video_{int(time.time())}"
        )
        # 设置连接回调
        self.client.on_connect = self.on_connect
        # 设置断开连接回调
        self.client.on_disconnect = self.on_disconnect
        # 设置错误回调
        self.client.on_error = self.on_error
        # 优化重连策略
        self.client.reconnect_delay_set(min_delay=1.0, max_delay=5.0)
        # 启用自动重连
        self.client.auto_reconnect = True
        # 设置遗嘱消息
        self.client.will_set(self.video_topic, payload='{"status":"disconnected"}', qos=0, retain=False)
    
    def on_connect(self, client, userdata, flags, rc, properties):
        print(f"✅ MQTT 连接成功，返回码: {rc}")
    
    def on_disconnect(self, client, userdata, rc, properties):
        if rc != 0:
            print(f"⚠️ MQTT 意外断开连接，返回码: {rc}")
        else:
            print("🛑 MQTT 正常断开连接")
    
    def on_error(self, client, userdata, error):
        print(f"❌ MQTT 错误: {error}")
        
    def fetch_http_stream(self):
        """HTTP 抓取线程 - 只保留最新帧"""
        print(f"🎥 抓取: {self.video_url}")
        
        # 用 requests 流式读取，配合 raw 降低延迟
        session = requests.Session()
        # 禁用连接池，避免缓冲积累
        session.keep_alive = False
        
        while True:
            try:
                # 关键：设置更合理的超时，避免频繁重连
                resp = session.get(
                    self.video_url, 
                    stream=True, 
                    timeout=(0.5, 2.0)  # (连接超时, 读取超时)
                )
                
                # 禁用 HTTP 缓冲
                resp.raw.decode_content = True
                
                buffer = b''
                # 进一步减少 chunk_size 到 512 字节，减少缓冲延迟
                for chunk in resp.iter_content(chunk_size=512):
                    if not chunk:
                        break
                    buffer += chunk
                    
                    # 查找 JPEG 帧边界 (FF D8 ... FF D9)
                    while True:


                        # find 方法返回 -1 表示未找到，确保 end > start 避免错误帧
                        # \xff\xd8 是 JPEG 起始标志，\xff\xd9 是 JPEG 结束标志
                        start = buffer.find(b'\xff\xd8')
                        end = buffer.find(b'\xff\xd9')
                        
                        if start != -1 and end != -1 and end > start:
                            # []切片获取完整 JPEG 数据
                            jpeg = buffer[start:end+2]
                            # 立即清空缓冲区，避免积累
                            buffer = buffer[end+2:]
                            
                            # 记录真实抓取时间戳
                            capture_time = int(time.time() * 1000)
                            
                            # 只保留最新帧（旧帧直接丢弃）
                            try:
                                self.frame_queue.put_nowait((jpeg, capture_time))
                            except:
                                # 队列满，丢弃旧帧
                                try:
                                    self.frame_queue.get_nowait()
                                    self.frame_queue.put_nowait((jpeg, capture_time))
                                except:
                                    pass
                        else:
                            break
                            
            except Exception as e:
                print(f"⚠️ HTTP 错误: {e}, 0.5秒后重连...")
                time.sleep(0.5)  # 更短的重连间隔
                
    def process_and_send(self):
        """处理发送线程 - 只发最新帧"""
        last_send_time = 0
        frame_interval = 1.0 / self.target_fps
        
        while True:
            try:
                # 获取最新帧（超时0.01秒，避免阻塞）
                try:
                    jpeg, capture_time = self.frame_queue.get(timeout=0.01)
                except Empty:
                    continue
                
                current_time = time.time()
                current_time_ms = int(current_time * 1000)

                # 启动阶段优先实时性：过旧帧直接丢弃
                # 最大帧龄居然是1.2s？？？
                if current_time_ms - capture_time > self.max_frame_age_ms:
                    continue

                # 限制帧率
                if current_time - last_send_time < frame_interval:
                    continue
                last_send_time = current_time
                
                if self.use_passthrough:
                    # 直接复用 HTTP 流中的 JPEG，降低处理延迟
                    encoded_bytes = jpeg
                else:
                    # 需要重编码时保留原流程，便于后续调参
                    np_arr = np.frombuffer(jpeg, dtype=np.uint8)
                    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                    if frame is None:
                        continue

                    frame = cv2.resize(frame, (480, 360), interpolation=cv2.INTER_NEAREST)
                    success, encoded = cv2.imencode('.jpg', frame, [
                        cv2.IMWRITE_JPEG_QUALITY, 70,
                        cv2.IMWRITE_JPEG_OPTIMIZE, 0
                    ])
                    if not success:
                        continue
                    encoded_bytes = encoded.tobytes()
                
                # 构建二进制消息
                # 前4字节是时间戳（大端，取低32位）
                timestamp_bytes = struct.pack('>I', capture_time & 0xFFFFFFFF)
                # 剩余部分是JPEG数据
                binary_payload = timestamp_bytes + encoded_bytes
                
                # MQTT 发送（QoS 0，不保留，极速模式）
                self.client.publish(self.video_topic, binary_payload, qos=0, retain=False)
                
                # 移除固定睡眠，由队列自然节流
                
            except Empty:
                continue
            except Exception as e:
                print(f"处理错误: {e}")
                
    def run(self):
        # 使用更合理的 keepalive，平衡心跳和网络开销
        self.client.connect(self.mqtt_broker, self.mqtt_port, keepalive=60)
        # 使用 loop_forever 替代 loop_start，提供更稳定的连接管理
        self.client.loop_start()
        
        # 双线程：抓取 + 发送并行
        fetch_thread = threading.Thread(target=self.fetch_http_stream, daemon=True)
        send_thread = threading.Thread(target=self.process_and_send, daemon=True)
        
        fetch_thread.start()
        send_thread.start()
        
        print("⚡ 高清晰度低延迟模式启动 | 目标延迟 < 300ms")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 停止")

if __name__ == '__main__':
    GO2VideoProxy().run()