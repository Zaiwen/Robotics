"""
GO2 HTTP → MQTT 视频代理
从本地 HTTP 视频流抓取，压缩后转 MQTT Base64
"""

import requests
import cv2
import numpy as np
import paho.mqtt.client as mqtt
import base64
import json
import time
import threading
from io import BytesIO

class GO2VideoProxy:
    def __init__(self):
        # GO2 本地 HTTP 视频流（网线直连时用的地址）
        self.video_url = "http://127.0.0.1:5000/video_stream"  # 或 192.168.1.18:5000
        
        # MQTT 配置
        self.mqtt_broker = 'broker.emqx.io'
        self.mqtt_port = 1883
        self.video_topic = 'go2/video/stream'
        
        self.client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"go2_video_proxy_{int(time.time())}"
        )
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        
        self.running = True
        self.frame_count = 0
        self.last_time = time.time()
        
    def on_connect(self, client, userdata, flags, rc, properties):
        print(f"✅ MQTT 连接成功: {self.mqtt_broker}")
        
    def on_disconnect(self, client, userdata, rc, properties):
        print(f"⚠️ MQTT 断开，代码: {rc}")
        
    def connect_mqtt(self):
        try:
            self.client.connect(self.mqtt_broker, self.mqtt_port, keepalive=60)
            self.client.loop_start()
        except Exception as e:
            print(f"❌ MQTT 连接失败: {e}")
            raise
            
    def fetch_and_publish(self):
        """抓取 HTTP 视频流并转 MQTT"""
        print(f"🎥 开始抓取视频流: {self.video_url}")
        print(f"📡 发布到 MQTT: {self.mqtt_broker}/{self.video_topic}")
        
        # 使用 OpenCV 读取 HTTP 视频流
        cap = cv2.VideoCapture(self.video_url)
        
        if not cap.isOpened():
            print(f"❌ 无法打开视频流: {self.video_url}")
            return
            
        # 设置缓冲区大小（降低延迟）
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        while self.running:
            ret, frame = cap.read()
            if not ret:
                print("⚠️ 读取帧失败，重试...")
                time.sleep(0.1)
                continue
            
            try:
                # 压缩为 320x240，降低带宽
                frame = cv2.resize(frame, (320, 240))
                
                # JPEG 编码，质量 30（平衡画质和带宽）
                encode_params = [cv2.IMWRITE_JPEG_QUALITY, 30]
                success, encoded = cv2.imencode('.jpg', frame, encode_params)
                
                if not success:
                    continue
                    
                # Base64 编码
                b64_data = base64.b64encode(encoded.tobytes()).decode('utf-8')
                
                # 打包 JSON
                payload = json.dumps({
                    'type': 'video_frame',
                    'data': b64_data,
                    'ts': time.time(),
                    'quality': 30,
                    'res': '320x240'
                })
                
                # MQTT 发布（QoS 0 降低延迟）
                self.client.publish(self.video_topic, payload, qos=0)
                
                # 统计 FPS
                self.frame_count += 1
                if self.frame_count % 30 == 0:
                    elapsed = time.time() - self.last_time
                    fps = 30 / elapsed
                    size_kb = len(payload) / 1024
                    print(f"📊 FPS: {fps:.1f} | 帧大小: {size_kb:.1f}KB | 总帧数: {self.frame_count}")
                    self.last_time = time.time()
                    
                # 控制帧率约 10fps（避免 MQTT 拥塞）
                time.sleep(0.1)
                
            except Exception as e:
                print(f"❌ 处理帧错误: {e}")
                
        cap.release()
        print("🛑 视频抓取已停止")
        
    def run(self):
        self.connect_mqtt()
        
        # 等待 MQTT 连接建立
        time.sleep(1)
        
        try:
            self.fetch_and_publish()
        except KeyboardInterrupt:
            print("\n🛑 收到中断信号")
        finally:
            self.running = False
            self.client.loop_stop()
            self.client.disconnect()
            print("👋 已关闭")

if __name__ == '__main__':
    proxy = GO2VideoProxy()
    proxy.run()
