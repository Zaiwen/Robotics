"""
GO2 HTTP → MQTT 视频代理（超低延迟版）
"""

import requests
import cv2
import numpy as np
import paho.mqtt.client as mqtt
import base64
import json
import time
import threading
from queue import Queue, Empty
import io

class GO2VideoProxyFast:
    def __init__(self):
        self.video_url = "http://127.0.0.1:5000/video_stream"
        self.mqtt_broker = 'broker.emqx.io'
        self.mqtt_port = 1883
        self.video_topic = 'go2/video/stream'
        
        # 关键：只保留最新帧的队列（大小=1，自动丢旧帧）
        self.frame_queue = Queue(maxsize=1)
        self.latest_frame_time = 0
        
        self.client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"go2_fast_{int(time.time())}"
        )
        self.client.on_connect = lambda c,u,f,rc,props: print("✅ MQTT OK")
        
    def fetch_http_stream(self):
        """HTTP 抓取线程 - 只保留最新帧"""
        print(f"🎥 抓取: {self.video_url}")
        
        # 用 requests 流式读取，配合 raw 降低延迟
        session = requests.Session()
        
        while True:
            try:
                # 关键：设置超时，强制断连重连清除缓冲
                resp = session.get(
                    self.video_url, 
                    stream=True, 
                    timeout=(0.5, 2.0)  # (连接超时, 读取超时)
                )
                
                buffer = b''
                for chunk in resp.iter_content(chunk_size=1024):
                    buffer += chunk
                    
                    # 查找 JPEG 帧边界 (FF D8 ... FF D9)
                    while True:
                        start = buffer.find(b'\xff\xd8')
                        end = buffer.find(b'\xff\xd9')
                        
                        if start != -1 and end != -1 and end > start:
                            jpeg = buffer[start:end+2]
                            buffer = buffer[end+2:]
                            
                            # 只保留最新帧（旧帧直接丢弃）
                            try:
                                self.frame_queue.put_nowait(jpeg)
                            except:
                                # 队列满，丢弃旧帧
                                try:
                                    self.frame_queue.get_nowait()
                                    self.frame_queue.put_nowait(jpeg)
                                except:
                                    pass
                        else:
                            break
                            
            except Exception as e:
                print(f"⚠️ HTTP 错误: {e}, 1秒后重连...")
                time.sleep(1)
                
    def process_and_send(self):
        """处理发送线程 - 只发最新帧"""
        while True:
            try:
                # 获取最新帧（超时 0.1 秒，避免阻塞）
                jpeg = self.frame_queue.get(timeout=0.1)
                
                # 解码检查（确保是有效图片）
                np_arr = np.frombuffer(jpeg, dtype=np.uint8)
                frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                if frame is None:
                    continue
                
                # 极速压缩：160x120，质量 20（牺牲画质换速度）
                frame = cv2.resize(frame, (160, 120), interpolation=cv2.INTER_LINEAR)
                _, encoded = cv2.imencode('.jpg', frame, [
                    cv2.IMWRITE_JPEG_QUALITY, 20,
                    cv2.IMWRITE_JPEG_OPTIMIZE, 1
                ])
                
                # Base64（用标准库加速）
                b64 = base64.b64encode(encoded.tobytes()).decode('ascii')
                
                # 极简 JSON（减少传输量）
                payload = f'{{"t":{int(time.time()*1000)},"d":"{b64}"}}'
                
                # MQTT 发送（QoS 0，不保留，极速模式）
                self.client.publish(self.video_topic, payload, qos=0, retain=False)
                
                # 控制发送频率：最多 15fps（避免 MQTT 拥塞）
                time.sleep(0.066)  # 66ms ≈ 15fps
                
            except Empty:
                continue
            except Exception as e:
                print(f"处理错误: {e}")
                
    def run(self):
        self.client.connect(self.mqtt_broker, self.mqtt_port, keepalive=30)
        self.client.loop_start()
        
        # 双线程：抓取 + 发送并行
        fetch_thread = threading.Thread(target=self.fetch_http_stream, daemon=True)
        send_thread = threading.Thread(target=self.process_and_send, daemon=True)
        
        fetch_thread.start()
        send_thread.start()
        
        print("⚡ 极速模式启动 | 目标延迟 < 500ms")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 停止")

if __name__ == '__main__':
    GO2VideoProxyFast().run()
