"""
GO2 MQTT 摄像头发布器 (ROS → MQTT)
从 ROS 摄像头话题接收，转 MQTT Base64
"""

import rospy
import cv2
import paho.mqtt.client as mqtt
import base64
import json
import time
from sensor_msgs.msg import CompressedImage, Image
from cv_bridge import CvBridge

class GO2MqttCamera:
    def __init__(self):
        # 初始化 ROS
        rospy.init_node('go2_mqtt_camera', anonymous=True)
        
        # MQTT 连接
        self.client = mqtt.Client(client_id=f"go2_cam_{int(time.time())}")
        self.client.on_connect = lambda c,u,f,rc: print(f"MQTT {'OK' if rc==0 else 'FAIL'}")
        self.client.connect('broker.emqx.io', 1883)
        self.client.loop_start()
        
        self.bridge = CvBridge()
        self.frame_count = 0
        self.last_time = time.time()
        
        # 订阅 ROS 压缩图像话题（GO2 通常是压缩的）
        rospy.Subscriber('/camera/compressed', CompressedImage, self.image_callback)
        # 或者非压缩的：rospy.Subscriber('/camera/image_raw', Image, self.image_callback)
        
    def image_callback(self, msg):
        try:
            # 解码压缩图像
            np_arr = np.frombuffer(msg.data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # 缩放降低带宽
            frame = cv2.resize(frame, (320, 240))
            
            # 编码为 JPEG
            _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 30])
            jpg_bytes = buffer.tobytes()
            
            # Base64 编码
            b64 = base64.b64encode(jpg_bytes).decode('utf-8')
            
            # MQTT 发送
            payload = json.dumps({
                'type': 'video_frame',
                'data': b64,
                'ts': time.time()
            })
            
            self.client.publish('go2/video/stream', payload)
            
            # 统计
            self.frame_count += 1
            if self.frame_count % 25 == 0:
                fps = 25 / (time.time() - self.last_time)
                print(f"FPS: {fps:.1f}, 大小: {len(payload)/1024:.1f}KB")
                self.last_time = time.time()
                
        except Exception as e:
            print(f"处理帧失败: {e}")
    
    def run(self):
        print("🎥 GO2 MQTT 摄像头启动 (ROS → MQTT)")
        print("   订阅: /camera/compressed")
        print("   发布: mqtt://broker.emqx.io/go2/video/stream")
        rospy.spin()

if __name__ == '__main__':
    import numpy as np
    GO2MqttCamera().run()
