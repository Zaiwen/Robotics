from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_01',
            executable='twist_bridge',
            name='twist_bridge',
            output='screen'
        ),
        Node(
            package='gscam2',
            executable='gscam_main',
            name='gscam_main',
            output='screen'
        ),
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',
            name='d435i',
            output='screen',
            parameters=[{
                'enable_color': True,
                'enable_depth': False,
                'rgb_camera.profile': '640x480x30'
            }],
        ),
        Node(
            package='demo_01',
            executable='camera_flask',
            name='camera_flask',
            output='screen',
            # --- 修改部分: 使用 parameters 传递 ROS 2 参数 ---
            parameters=[
                {'image_topic': '/image_raw'},  # 对应您原来的 arguments=['/images_raw']
                {'http_port': 5000}             # 设置 Flask 服务器的端口，使用默认值或您需要的端口
            ]
            # --- 结束修改部分 ---
        ),
        Node(
            package='demo_01',
            executable='camera_flask',
            name='camera_flask',
            output='screen',
            # --- 修改部分: 使用 parameters 传递 ROS 2 参数 ---
            parameters=[
                {'image_topic': '/color/image_raw'},  # 对应您原来的 arguments=['/images_raw']
                {'http_port': 5001}             # 设置 Flask 服务器的端口，使用默认值或您需要的端口
            ]
            # --- 结束修改部分 ---
        ),
        Node(
            package='rosbridge_server',
            executable='rosbridge_websocket',
            name='rosbridge_websocket',
            output='screen',
            parameters=[{'port': 9090}]  # 保持 rosbridge 的配置不变
        )
    ])