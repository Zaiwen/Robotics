# ~/ros2_ws/install/mqtt_go2_sport_control.py
import time
import paho.mqtt.client as mqtt
from unitree_sdk2py.core.channel import ChannelFactoryInitialize
from unitree_sdk2py.go2.sport.sport_client import SportClient

# ---------- 配置 ----------
BROKER = "10.121.151.103"   # 也可换成你自建的 MQTT 服务器
PORT   = 1883
TOPIC_CMD    = "jetson/cmd"
TOPIC_RESULT = "jetson/result"

# ---------- 初始化 Unitree 通道与运动客户端 ----------
print("初始化 Unitree 通道 ...")
ChannelFactoryInitialize(0)       # 默认 UDP 通道
sport_client = SportClient()
sport_client.SetTimeout(10.0)
sport_client.Init()
print("运动客户端就绪")

# ---------- 定义动作函数 ----------
def do_standup():
    sport_client.StandUp()

def do_sitdown():
    sport_client.StandDown()

def do_forward():
    # (前进速度, 侧向速度, 旋转速度) 建议温和值
    sport_client.Move(0.30, 0.0, 0.0)

def do_backward():
    sport_client.Move(-0.30, 0.0, 0.0)

def do_left():
    sport_client.Move(0.0, 0.0, 0.50)

def do_right():
    sport_client.Move(0.0, 0.0, -0.50)

def do_stop():
    sport_client.StopMove()

def do_backflip():
    # 直体后空翻
    sport_client.BackFlip()

def do_handstand():
    # True 进入，False 退出
    sport_client.HandStand(True)
    time.sleep(4)
    sport_client.HandStand(False)

def do_walk_sequence():
    # 示例复合动作：站起 → 前进 2s → 左转 1s → 停止 → 趴下
    sport_client.StandUp()
    time.sleep(1.0)
    sport_client.Move(0.30, 0.0, 0.0); time.sleep(2.0)
    sport_client.Move(0.0, 0.0, 0.50); time.sleep(1.0)
    sport_client.StopMove()
    sport_client.StandDown()

# 指令 → 动作映射（后续要加动作，只需在这里扩展）
ACTIONS = {
    "standup":       do_standup,
    "sitdown":       do_sitdown,
    "forward":       do_forward,
    "backward":      do_backward,
    "left":          do_left,
    "right":         do_right,
    "stop":          do_stop,
    "backflip":      do_backflip,
    "handstand":     do_handstand,
    "walk_sequence": do_walk_sequence,
}

# ---------- MQTT 逻辑 ----------


# protocol 表示 MQTT 协议版本，MQTTv311 是目前最常用的版本，兼容性好
client = mqtt.Client(client_id=f"go2-sport-{int(time.time())}", protocol=mqtt.MQTTv311)

def on_connect(client, userdata, flags, rc, properties=None):
    print("已连接 MQTT，返回码:", rc)
    client.subscribe(TOPIC_CMD)
    print(f"订阅: {TOPIC_CMD}")

def on_message(client, userdata, msg):
    cmd = msg.payload.decode(errors="ignore").strip()
    print(f"指令: {cmd}")
    action = ACTIONS.get(cmd)
    if action is None:
        client.publish(TOPIC_RESULT, f"未知指令: {cmd}")
        return
    try:
        action()
        client.publish(TOPIC_RESULT, f"{cmd} 执行完成")
    except Exception as e:
        client.publish(TOPIC_RESULT, f"{cmd} 执行失败: {e}")

client.on_connect = on_connect
client.on_message = on_message

print(f"连接 MQTT: {BROKER}:{PORT} ...")


# keepalive 参数表示客户端与服务器之间的心跳间隔，单位为秒
# 设置为 60 表示每 60 秒发送一次心跳包
client.connect(BROKER, PORT, keepalive=60)


# retry_first_connection 参数表示在初始连接失败时是否自动重试连接，True 表示启用自动重试
client.loop_forever(retry_first_connection=True)
