import cv2
import numpy as np
import paho.mqtt.client as mqtt
import time
import json
import struct
from datetime import datetime
import argparse
import socket
import threading


def get_local_ip():
    """自动检测本地网络IP地址，优先选择手机热点IP"""
    try:
        # 尝试直接获取所有网络接口的IP地址
        import socket
        
        # 获取主机名
        hostname = socket.gethostname()
        # 获取所有IP地址
        ip_addresses = socket.gethostbyname_ex(hostname)[2]
        
        # 优先选择手机热点IP（192.168.43.x）
        for ip in ip_addresses:
            if ip.startswith('192.168.43.'):
                print(f'Found hotspot IP: {ip}')
                return ip
        
        # 尝试使用另一种方法获取IP地址
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        
        # 检查获取到的IP是否是热点IP
        if ip.startswith('192.168.43.'):
            print(f'Found hotspot IP: {ip}')
        else:
            print(f'Using network IP: {ip}')
        
        return ip
    except Exception as e:
        print(f'Warning: Auto-detect IP failed: {e}')
        # 直接使用192.168.43.1作为热点IP
        print('Using fallback hotspot IP: 192.168.43.1')
        return '192.168.43.1'  # 默认值


def start_broadcast(ip, port=1883, websocket_port=8083):
    """启动UDP广播，发送MQTT服务器信息"""
    def broadcast_thread():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.2)
        
        # 广播地址
        broadcast_address = '<broadcast>'
        broadcast_port = 18830  # 广播端口
        
        # 广播消息
        message = json.dumps({
            'type': 'go2_mqtt_server',
            'ip': ip,
            'port': port,
            'websocket_port': websocket_port,
            'timestamp': time.time()
        })
        
        print(f'Starting UDP broadcast service, IP: {ip}, Port: {port}, WebSocket Port: {websocket_port}')
        
        try:
            while True:
                try:
                    sock.sendto(message.encode(), (broadcast_address, broadcast_port))
                    # print(f'📡 发送广播: {message}')
                    time.sleep(2)  # 每2秒广播一次
                except Exception as e:
                    print(f'Warning: Broadcast failed: {e}')
                    time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            sock.close()
    
    # 启动广播线程
    thread = threading.Thread(target=broadcast_thread, daemon=True)
    thread.start()
    return thread


class Go2VideoMQTT:
    def __init__(self, broker_ip=None, broker_port=1883, 
                 websocket_port=8083,
                 camera_url=None,
                 video_topic='go2/video/stream',
                 use_binary=True,
                 quality=70,  # 降低质量以提高流畅度
                 fps=20):  # 提高帧率
        # 如果没有指定broker_ip，自动检测本地IP
        self.broker_ip = broker_ip if broker_ip else get_local_ip()
        self.broker_port = broker_port
        self.websocket_port = websocket_port
        # 如果没有指定camera_url，使用默认地址
        if camera_url:
            self.camera_url = camera_url
        else:
            # self.camera_url = f"rtsp://{self.broker_ip}:8554/stream"
            self.camera_url = "http://127.0.0.1:5000/video_stream"
        self.video_topic = video_topic
        self.use_binary = use_binary
        self.quality = quality
        self.target_fps = fps
        self.frame_interval = 1.0 / fps
        self.client = None
        self.cap = None
        self.running = False
        self.frame_count = 0
        self.last_frame_time = 0

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print(f'Connected to MQTT broker {self.broker_ip}:{self.broker_port}')
        else:
            print(f'MQTT connection failed, return code: {rc}')

    def on_disconnect(self, client, userdata, rc):
        if rc != 0:
            print(f'MQTT unexpected disconnection, return code: {rc}')

    def connect_mqtt(self):
        self.client = mqtt.Client(client_id='go2_video_publisher', 
                                  protocol=mqtt.MQTTv311,
                                  transport='tcp')
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        
        try:
            self.client.connect(self.broker_ip, self.broker_port, keepalive=60)
            self.client.loop_start()
            time.sleep(1)
            return True
        except Exception as e:
            print(f'Failed to connect to MQTT broker: {e}')
            return False

    def connect_camera(self):
        print(f'Connecting to camera: {self.camera_url}')
        print('Note: Go2 robot dog\'s default camera address might be rtsp://192.168.123.1:8554/stream')
        print('If connection fails, please try using --camera parameter to specify the correct camera address')
        
        # 尝试多种不同的摄像头地址格式
        camera_urls = [self.camera_url]
        
        # 添加常见的Go2摄像头地址
        if '192.168.123.1' not in self.camera_url:
            camera_urls.append('rtsp://192.168.123.1:8554/stream')
        if 'localhost' not in self.camera_url:
            camera_urls.append('rtsp://localhost:8554/stream')
        if '127.0.0.1' not in self.camera_url:
            camera_urls.append('rtsp://127.0.0.1:8554/stream')
        
        for url in camera_urls:
            print(f'Trying to connect: {url}')
            self.cap = cv2.VideoCapture(url)
            
            if self.cap.isOpened():
                print(f'Camera connected successfully: {url}')
                self.camera_url = url  # 更新为成功的地址
                return True
            else:
                print(f'Failed to open camera: {url}')
                if self.cap:
                    self.cap.release()
        
        print('All camera addresses failed to connect')
        print('Please check:')
        print('1. Is the Go2 robot dog started and connected to the network')
        print('2. Is the camera service running')
        print('3. Is the network connection normal')
        print('4. Is the camera address correct')
        return False

    def encode_frame(self, frame):
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), self.quality]
        _, jpeg_data = cv2.imencode('.jpg', frame, encode_param)
        return jpeg_data.tobytes()

    def publish_frame_binary(self, jpeg_data, timestamp):
        # 确保时间戳在无符号整数范围内 (0-4294967295)
        timestamp = int(timestamp) % 4294967296
        timestamp_bytes = struct.pack('>I', timestamp)
        payload = timestamp_bytes + jpeg_data
        self.client.publish(self.video_topic, payload, qos=0, retain=False)

    def publish_frame_json(self, jpeg_data, timestamp):
        import base64
        # 确保时间戳在合理范围内
        timestamp = int(timestamp)
        base64_data = base64.b64encode(jpeg_data).decode('utf-8')
        payload = json.dumps({
            't': timestamp,
            'd': base64_data
        })
        self.client.publish(self.video_topic, payload, qos=0, retain=False)

    def run(self):
        if not self.connect_mqtt():
            return False
        
        if not self.connect_camera():
            return False
        
        self.running = True
        print(f'Starting video stream transmission (target FPS: {self.target_fps}, quality: {self.quality})')
        print('Press Ctrl+C to stop')
        
        try:
            while self.running:
                current_time = time.time()
                elapsed = current_time - self.last_frame_time
                
                if elapsed < self.frame_interval:
                    time.sleep(0.001)
                    continue
                
                try:
                    ret, frame = self.cap.read()
                    if not ret:
                        print('Warning: Failed to read camera frame, trying to reconnect...')
                        time.sleep(1)
                        if not self.connect_camera():
                            continue
                        continue
                    
                    jpeg_data = self.encode_frame(frame)
                    timestamp = time.time() * 1000
                    
                    if self.use_binary:
                        self.publish_frame_binary(jpeg_data, timestamp)
                    else:
                        self.publish_frame_json(jpeg_data, timestamp)
                    
                    self.frame_count += 1
                    self.last_frame_time = current_time
                    
                    if self.frame_count % 30 == 0:
                        actual_fps = 30 / elapsed if elapsed > 0 else 0
                        print(f'Statistics: Sent {self.frame_count} frames, actual FPS: {actual_fps:.1f}, '  
                              f'frame size: {len(jpeg_data)/1024:.1f}KB')
                except Exception as e:
                    print(f'Warning: Error processing frame: {e}')
                    time.sleep(0.1)
                    continue
        
        except KeyboardInterrupt:
            print('\nReceived stop signal')
        
        finally:
            self.stop()

    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
        print(f'Stopped, total frames sent: {self.frame_count}')

def main():
    parser = argparse.ArgumentParser(description='GO2 robot dog video stream MQTT transmission')
    parser.add_argument('--broker', '-b', type=str, default=None,
                        help='MQTT broker IP address (default: auto-detect)')
    parser.add_argument('--port', '-p', type=int, default=1883,
                        help='MQTT broker port (default: 1883)')
    parser.add_argument('--websocket-port', '-w', type=int, default=8083,
                        help='MQTT broker WebSocket port (default: 8083)')
    parser.add_argument('--camera', '-c', type=str, 
                        default=None,
                        help='Camera RTSP address (default: http://127.0.0.1:5000/video_stream)')
    parser.add_argument('--topic', '-t', type=str, default='go2/video/stream',
                        help='MQTT video topic (default: go2/video/stream)')
    parser.add_argument('--json', action='store_true',
                        help='Use JSON format for transmission (default uses binary format)')
    parser.add_argument('--quality', '-q', type=int, default=70,
                        help='JPEG quality 1-100 (default: 70)')
    parser.add_argument('--fps', '-f', type=int, default=20,
                        help='Target FPS (default: 20)')
    
    args = parser.parse_args()
    
    # 打印自动检测的IP
    if not args.broker:
        detected_ip = get_local_ip()
        print(f'Auto-detected network IP: {detected_ip}')
    else:
        detected_ip = args.broker
    
    # 启动UDP广播服务
    broadcast_thread = start_broadcast(detected_ip, args.port, args.websocket_port)
    
    publisher = Go2VideoMQTT(
        broker_ip=args.broker,
        broker_port=args.port,
        websocket_port=args.websocket_port,
        camera_url=args.camera,
        video_topic=args.topic,
        use_binary=not args.json,
        quality=args.quality,
        fps=args.fps
    )
    
    publisher.run()

if __name__ == '__main__':
    main()
