import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from flask import Flask, Response
import io
import threading
# import argparse # 移除 argparse，因为它不再用于参数解析
from rcl_interfaces.msg import ParameterDescriptor # 导入ParameterDescriptor

# 初始化Flask应用
app = Flask(__name__)

# 创建一个全局变量来存储图像数据
current_image = None
current_frame_id = 0

# 创建ROS2节点类
class ImageSubscriber(Node):
    # 初始化函数不再接收 topic_name 参数
    def __init__(self):
        super().__init__('image_subscriber')
        
        # --- ROS 2 参数声明和获取 ---
        
        # 1. 声明并获取 HTTP 端口号参数
        port_descriptor = ParameterDescriptor(description='The port for the HTTP server.')
        self.declare_parameter('http_port', 5001, port_descriptor)


        # 获取参数值并存储在实例变量中，供后续使用
        self.http_port = self.get_parameter('http_port').get_parameter_value().integer_value

        # 2. 声明并获取 图像话题名称参数
        topic_descriptor = ParameterDescriptor(description='The name of the ROS2 topic to subscribe to.')
        # 默认值设置为 /camera/image_raw 是常见的做法
        self.declare_parameter('image_topic', '/camera/image_raw', topic_descriptor) 
        self.image_topic = self.get_parameter('image_topic').get_parameter_value().string_value
        
        # -----------------------------
        
        # 使用从参数服务获取的话题名称
        self.subscription = self.create_subscription(
            Image,
            self.image_topic,
            self.image_callback,
            10)
        self.subscription  # 防止订阅被自动销毁
        self.bridge = CvBridge()
        
        self.get_logger().info(f'Subscribing to topic: {self.image_topic}')
        self.get_logger().info(f'Flask server port set to: {self.http_port}')

    def image_callback(self, msg):
        global current_image, current_frame_id
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        # 将图像转换为JPEG格式
        _, buffer = cv2.imencode('.jpg', cv_image, [cv2.IMWRITE_JPEG_QUALITY, 70])
        current_image = buffer.tobytes()
        current_frame_id += 1

# 生成器函数，不断发送图像
def generate():
    import time
    global current_frame_id
    last_sent_id = -1

    while True:
        if current_image is None:
            time.sleep(0.01)
            continue

        # 没有新帧就短暂让出 CPU，避免重复发送相同帧
        if current_frame_id == last_sent_id:
            time.sleep(0.001)
            continue

        last_sent_id = current_frame_id
        # 使用 multipart/x-mixed-replace 格式发送图像数据，适合实时视频流
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + current_image + b'\r\n')

@app.route('/video_stream')
def video_stream():
    return Response(generate(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

# 全局变量来存储ROS2节点实例，以便在 main 函数中访问其 http_port 参数
ros_node = None 

def run_ros_node(): # 不再接收 topic_name 参数
    global ros_node
    rclpy.init()
    ros_node = ImageSubscriber() # 节点初始化时会读取参数

    # spin() 会阻塞当前线程，直到节点被销毁
    rclpy.spin(ros_node)
    
    # 清理和关闭ROS2节点
    # 程序结束时进行销毁和关闭，不是一写出来就执行
    ros_node.destroy_node()
    rclpy.shutdown()

def main(args=None):
    # 全局变量，共享
    global ros_node

    # # 移除 argparse 相关的代码
    # parser = argparse.ArgumentParser(description="Subscribe to a ROS2 image topic and serve it as a video stream.")
    # parser.add_argument('topic_name', type=str, help="The name of the ROS2 topic to subscribe to.")
    # args = parser.parse_args()

    # 创建线程运行ROS2节点
    ros_thread = threading.Thread(target=run_ros_node) # 不再传入参数
    ros_thread.start()
    
    # 简单的等待ROS节点初始化，以便获取参数
    import time

    # 暂停主线程2秒
    time.sleep(2) 
    
    # 确保节点已初始化
    if ros_node is None:
        print("Error: ROS Node failed to initialize.")
        # 阻塞主线程，等待ROS线程完成执行
        ros_thread.join()
        return

    # 从ROS节点实例获取配置的端口号
    http_port = ros_node.http_port

    # 启动Flask HTTP服务器
    try:
        # 使用从ROS参数获取的端口号
        # 允许其他设备通过网络访问该服务器
        app.run(host='0.0.0.0', port=http_port, threaded=True)
    except KeyboardInterrupt:
        pass
    finally:
        # 确保ROS线程可以优雅退出
        ros_thread.join()

if __name__ == '__main__':
    main()


